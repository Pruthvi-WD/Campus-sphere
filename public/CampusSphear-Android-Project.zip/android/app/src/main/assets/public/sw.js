/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "4b96ca324c2811a96ae20a983ea74f33"
  }, {
    "url": "pwa-512x512.png",
    "revision": "cad0546fe0c1a890e6199bdc74cae129"
  }, {
    "url": "pwa-192x192.png",
    "revision": "09df3336d6c482d8bfeef27d13e9e9df"
  }, {
    "url": "index.html",
    "revision": "1aa0e9546055e94422474486a1209f2b"
  }, {
    "url": "icon.svg",
    "revision": "2e80b993bc66e34870cdb06b62ca28d4"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "9e3c2cfe652c3ad87657f3e7c9df63a9"
  }, {
    "url": "assets/index-CuoT8e6A.css",
    "revision": null
  }, {
    "url": "assets/index-BXmdWNRP.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "9e3c2cfe652c3ad87657f3e7c9df63a9"
  }, {
    "url": "icon.svg",
    "revision": "2e80b993bc66e34870cdb06b62ca28d4"
  }, {
    "url": "pwa-192x192.png",
    "revision": "09df3336d6c482d8bfeef27d13e9e9df"
  }, {
    "url": "pwa-512x512.png",
    "revision": "cad0546fe0c1a890e6199bdc74cae129"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "4b96ca324c2811a96ae20a983ea74f33"
  }, {
    "url": "manifest.webmanifest",
    "revision": "de8cadba6e147d4549e9aeaafe026a9c"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));

}));
