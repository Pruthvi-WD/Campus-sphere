# Campus Sphear - GMU Android App Project

## How to Build in Android Studio
1. Extract this ZIP
2. Open Android Studio -> Open Folder -> select "android"
3. Wait for Gradle sync to complete
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s)
5. The APK will be generated in .

Package: com.gmu.campusphear
Target: Android 14+ (API 34)
Language: Java + Capacitor Native Bridge